#pragma once

#include "entities/entities.h"

namespace entities {

	class monster_basic : public monster {
	public:
		monster_basic(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 30.0f, 0.0f, 1.5f, 1.5f, 8.0f, 10.0f, 1.0f) {}
		void update(float dt) override;
	};

	class monster_ranged : public monster {
	public:
		float preferred_dist;
		monster_ranged(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 25.0f, 0.0f, 1.2f, 10.0f, 15.0f, 8.0f, 1.5f),
		                   preferred_dist(8.0f) {}
		void update(float dt) override;
	};

	class monster_assault : public monster {
	public:
		int   burst_size;
		float burst_interval;
		int   burst_remaining;
		float burst_timer;
		float burst_cooldown;
		float strafe_sign;
		float strafe_timer;

		monster_assault(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 60.0f, 10.0f, 2.0f, 6.0f, 12.0f, 7.0f, 0.2f),
		    burst_size(3), burst_interval(0.2f),
		    burst_remaining(0), burst_timer(0.0f), burst_cooldown(0.0f),
		    strafe_sign(1.0f), strafe_timer(0.0f) {}
		void update(float dt) override;
	};

	class monster_sniper : public monster {
	public:
		float shoot_interval;
		float aim_timer;

		monster_sniper(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 40.0f, 0.0f, 1.0f, 25.0f, 30.0f, 30.0f, 3.0f),
		    shoot_interval(3.0f), aim_timer(0.0f) {}
		void update(float dt) override;
	};

	class monster_trapper : public monster {
	public:
		int   max_traps;
		int   traps_placed;
		float trap_timer;
		float trap_interval;
		float wander_timer;
		float wander_sign;

		monster_trapper(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 45.0f, 15.0f, 3.0f, 3.0f, 8.0f, 15.0f),
		    max_traps(3), traps_placed(0),
		    trap_timer(0.0f), trap_interval(2.0f),
		    wander_timer(0.0f), wander_sign(1.0f) {}
		void update(float dt) override;
	};

	class monster_Duzy_Gruby : public monster {
	public:
		monster_Duzy_Gruby(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 200.0f, 50.0f, 0.8f, 2.0f, 6.0f, 25.0f, 2.0f) {}
		void update(float dt) override;
	};

	class monster_Maly_Szybki : public monster {
	public:
		bool  is_dashing;
		float dash_timer;
		float dash_cooldown;

		monster_Maly_Szybki(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 15.0f, 0.0f, 4.5f, 1.5f, 12.0f, 12.0f, 0.5f),
		    is_dashing(false), dash_timer(0.0f), dash_cooldown(0.0f) {}
		void update(float dt) override;
	};

	class monster_all_rounder : public monster {
	public:
		bool  melee_mode;
		float melee_threshold;

		monster_all_rounder(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 80.0f, 20.0f, 2.0f, 5.0f, 10.0f, 10.0f, 1.0f),
		    melee_mode(false), melee_threshold(2.5f) {}
		void update(float dt) override;
	};

	class monster_spawner : public monster {
	public:
		int   max_spawns;
		int   current_spawns;
		float spawn_interval;
		float spawn_timer;

		monster_spawner(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 100.0f, 20.0f, 0.0f, 0.0f, 15.0f),
		    max_spawns(5), current_spawns(0),
		    spawn_interval(5.0f), spawn_timer(0.0f) {}
		void update(float dt) override;
	};

	class monster_magic : public monster {
	public:
		float charge_time;
		float charge_timer;
		bool  is_charging;
		float post_fire_cooldown;
		float sidestep_timer;
		float sidestep_sign;

		monster_magic(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 50.0f, 30.0f, 1.5f, 12.0f, 15.0f, 40.0f, 2.0f),
		    charge_time(2.0f), charge_timer(0.0f), is_charging(false),
		    post_fire_cooldown(0.0f), sidestep_timer(0.0f), sidestep_sign(1.0f) {}
		void update(float dt) override;
	};

	class monster_elite_tank : public monster {
	public:
		bool  melee_mode;
		float melee_threshold;
		float heavy_timer;
		float heavy_cd;

		monster_elite_tank(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 400.0f, 150.0f, 1.2f, 2.5f, 8.0f, 15.0f, 1.2f),
		    melee_mode(false), melee_threshold(3.0f),
		    heavy_timer(0.0f), heavy_cd(6.0f) {}
		void update(float dt) override;
	};

	class monster_elite_swift : public monster {
	public:
		float charge_speed;
		bool  is_charging;
		float charge_timer;
		float charge_cd;
		float circle_angle;
		float circle_radius;

		monster_elite_swift(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 60.0f, 0.0f, 7.0f, 2.0f, 20.0f, 12.0f, 0.8f),
		    charge_speed(15.0f), is_charging(false),
		    charge_timer(0.0f), charge_cd(0.0f),
		    circle_angle(0.0f), circle_radius(5.0f) {}
		void update(float dt) override;
	};

	class monster_boss : public monster {
	public:
		int phase_count;

		monster_boss(math::vec2 const p, float const z, assets::texture_id const tex, float const is) : monster(p, z, tex, is, 1000.0f, 300.0f, 1.5f, 3.0f, 30.0f, 20.0f, 1.0f),
		    phase_count(3) {}
	};

}
