#pragma once
namespace res_symbols {
extern "C" {
    extern unsigned char const _binary_res_doom_floor_btx_start[];
    extern unsigned char const _binary_res_doom_floor_btx_end[];
    extern unsigned char const _binary_res_doom_wall_btx_start[];
    extern unsigned char const _binary_res_doom_wall_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_walls_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_walls_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_walls_test2_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_walls_test2_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_walls_test3_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_walls_test3_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_walls_test_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_walls_test_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_flat_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_flat_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_flat_font_atlas_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_flat_font_atlas_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_flat_hud_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_flat_hud_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_ui_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_ui_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_ui_background_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_ui_background_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_ui_cursor_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_ui_cursor_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_ui_button_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_ui_button_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_score_display_start[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_score_display_end[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_options_start[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_options_end[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_start_start[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_start_end[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_quit_start[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_quit_end[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_name_display_start[];
    extern unsigned char const _binary_res_cultured_textures_menu_elements_name_display_end[];
    extern unsigned char const _binary_res_cultured_textures_menus_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_menus_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_menus_main_start[];
    extern unsigned char const _binary_res_cultured_textures_menus_main_end[];
    extern unsigned char const _binary_res_cultured_textures_sprite_manifest_start[];
    extern unsigned char const _binary_res_cultured_textures_sprite_manifest_end[];
    extern unsigned char const _binary_res_cultured_textures_sprite_magic_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_sprite_magic_btx_end[];
    extern unsigned char const _binary_res_cultured_textures_sprite_test_btx_start[];
    extern unsigned char const _binary_res_cultured_textures_sprite_test_btx_end[];
    extern unsigned char const _binary_res_hello_world_txt_start[];
    extern unsigned char const _binary_res_hello_world_txt_end[];
    extern unsigned char const _binary_res_meta_texture_sets_start[];
    extern unsigned char const _binary_res_meta_texture_sets_end[];
}
}
